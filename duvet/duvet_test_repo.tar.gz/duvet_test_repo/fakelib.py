def noop():
    pass

def do_something(x):
    return (x + 1) - x
